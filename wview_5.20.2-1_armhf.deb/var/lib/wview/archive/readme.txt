wview-archive.sdb           - Empty "starter" archive database
wview-archive.sql           - SQL file for archive table creation
