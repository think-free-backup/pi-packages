<?php
//
//  File:       login.php
//
//  Purpose:    Provide a well-known URL name for entry.
//

    header('Location: ' . 'system_status.php');

?>