<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title>wview Management Logout</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"><link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>

<div id="mainForm">
  <center>
    <br>
    You are now logged out of wview Management
    <br>
    <br>
    <a href=system_status.php>Back to wview Management</a>
    <br>
    <br>
  </center>
</div>

<div id="footer">
    <p class="footer">
        Brought to you by <a class=footer href=http://www.wviewweather.com>wviewweather.com</a>
    </p>
</div>

</body>
</html>
