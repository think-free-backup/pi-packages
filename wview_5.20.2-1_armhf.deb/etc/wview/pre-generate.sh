#/bin/sh

# Add any pre template generation processing or utilities here. Keep in mind this 
# script runs in the htmlgend process's context so don't add anything that is overly
# time constrained.

exit 0

